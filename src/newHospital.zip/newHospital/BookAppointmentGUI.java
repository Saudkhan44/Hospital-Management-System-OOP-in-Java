package newHospital;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class BookAppointmentGUI extends JFrame implements ActionListener {
    private JComboBox<String> doctorDropdown;
    private JTextField dateField;
    private JButton bookBtn, backBtn;
    private Patient loggedInPatient;  // pass current logged-in patient

    public BookAppointmentGUI(Patient patient) {
        this.loggedInPatient = patient;

        setTitle("📅 Book Appointment - Malik Hospital");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JLabel titleLabel = new JLabel("📅 Book an Appointment", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setForeground(new Color(0, 102, 204));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        add(titleLabel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridLayout(3, 2, 10, 15));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        formPanel.add(new JLabel("Select Doctor:"));
        doctorDropdown = new JComboBox<>();
        for (Doctor d : HospitalData.doctorList) {
            doctorDropdown.addItem(d.getName());// show name
        }
        formPanel.add(doctorDropdown);

        formPanel.add(new JLabel("Appointment Date (dd-MM-yyyy):"));
        dateField = new JTextField();
        formPanel.add(dateField);

        add(formPanel, BorderLayout.CENTER);

        // Buttons
        JPanel buttonPanel = new JPanel();
        bookBtn = new JButton("Book");
        backBtn = new JButton("Back");

        bookBtn.setBackground(new Color(0, 153, 76));
        bookBtn.setForeground(Color.WHITE);
        backBtn.setBackground(new Color(153, 0, 0));
        backBtn.setForeground(Color.WHITE);

        buttonPanel.add(bookBtn);
        buttonPanel.add(backBtn);
        add(buttonPanel, BorderLayout.SOUTH);

        bookBtn.addActionListener(this);
        backBtn.addActionListener(this);

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == bookBtn) {
            String selectedDoctorName = (String) doctorDropdown.getSelectedItem();
            String dateStr = dateField.getText();

            if (dateStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a date.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                // Parse date string
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
                Date appointmentDate = sdf.parse(dateStr);

                // Find the Doctor object by name
                Doctor selectedDoctor = null;
                for (Doctor d : HospitalData.doctorList) {
                    if (d.getName().equals(selectedDoctorName)) {
                        selectedDoctor = d;
                        break;
                    }
                }

                if (selectedDoctor == null) {
                    JOptionPane.showMessageDialog(this, "Selected doctor not found.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Book appointment
                loggedInPatient.bookAppointment(selectedDoctor, appointmentDate);
                JOptionPane.showMessageDialog(this, "Appointment booked successfully!");

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid date format! Use dd-MM-yyyy.", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } else if (e.getSource() == backBtn) {
            dispose();
            new PatientDashboardGUI(loggedInPatient);
        }
    }
}


// VIEW APPOINTMENTS:
class ViewAppointmentsGUI extends JFrame {

    public ViewAppointmentsGUI(Patient loggedInPatient) {
        setTitle("📋 My Appointments - Malik Hospital");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JLabel titleLabel = new JLabel("📋 My Appointments", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLabel.setForeground(new Color(0, 102, 204));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        add(titleLabel, BorderLayout.NORTH);

        // Table columns
        String[] columns = {"Doctor", "Date", "Status"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);
        JTable table = new JTable(model);

        // Populate table from patient appointments
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");

        for (Appointment appt : loggedInPatient.getAppointments()) {
            String doctorName = appt.getDoctor().getName();
            String dateStr = sdf.format(appt.getDate());
            String status = appt.getStatus().toString();
            model.addRow(new Object[]{doctorName, dateStr, status});
        }

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        setVisible(true);
    }
}


