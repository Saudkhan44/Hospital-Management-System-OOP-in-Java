package newHospital;

import java.util.ArrayList;

public class HospitalData {
    public static ArrayList<Patient> patientList = new ArrayList<>();
    public static ArrayList<Doctor> doctorList = new ArrayList<>();
    public static ArrayList<LabTechnician> labList = new ArrayList<>();
//    public static ArrayList<LabTechnician> prescriptions = new ArrayList<>();

}

